package com.wangzhixuan.commons.report.excel;

/**
 * Created by lcm on 16/4/22.
 */
public enum ExcelCellType {
	TEXT, NUMBER, DATE, BOOL
}
