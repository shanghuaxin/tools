dubbo项目.
分 api(接口),provider(提供者),web(消费者) 三个子模块.
provider以jar包方式运行.