#TODO
1.Easyui Accordion

2.sys模块，字典

3.Activiti工作流